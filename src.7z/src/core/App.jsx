import React from 'react'
import SwitchContainer from '../widgets/SwitchContainer'
import Styles from './App.module.css'

export default function App() {
    return (
        <div className={Styles.App}>
            <ul className={Styles.Menu}>
                <li><a href='/'>Страница 1</a></li>
                <li><a href='/'>Страница 2</a></li>
                <li><a href='/'>Страница 3</a></li>
            </ul>
            <div className={Styles.Content}>
                <SwitchContainer Index={2}>
                    <span>Элемент 1</span>
                    <span>Элемент 2</span>
                    <span>Элемент 3</span>
                </SwitchContainer>
            </div>
        </div>
    )
}
